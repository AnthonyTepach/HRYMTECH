<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="row">
    <div class="twelve column">
    	<h4 class="bounceInLeft animated">Galeria</h4>
    		
    </div>
</div>
